import mapel

mapel.hello()

mapel.print_2d("testbed_100_100", mask=True)
