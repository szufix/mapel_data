import sys
sys.path.append('C:/Users/Snochacz/Anaconda3/Lib/site-packages/')
#sys.path.append('C:/Users/Snochacz/Documents/GitHub/mapel')
import mapel
mapel.hello()

mapel.print_matrix("testbed_100_100", scale=0.1)
