#
# PRINT MAP COLORED BY YOUR OWN FEATURE
#

import mapel.elections as mapel

import random as rand


def my_feature(election):
    """ implement your feature here """
    return rand.randint(0, 100)


if __name__ == "__main__":

    experiment_id = '10x50'
    distance_id = 'swap'
    embedding_id = 'fr'

    experiment = mapel.prepare_offline_approval_experiment(experiment_id=experiment_id,
                                                           distance_id=distance_id,
                                                           embedding_id=embedding_id)

    experiment.add_feature('my_feature', my_feature)
    experiment.compute_feature('my_feature')

    experiment.print_map_2d_colored_by_feature(
        cmap='Oranges',
        feature_id='my_feature',
        textual=['ID', 'UN', 'ST', 'AN'],
        rounding=0,
    )
