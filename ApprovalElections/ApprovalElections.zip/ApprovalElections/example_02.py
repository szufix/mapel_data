#
# PRINT MAP COLORED BY FEATURE
#

import mapel.elections as mapel


if __name__ == "__main__":

    experiment_id = 'resampling'    # or disjoint or noise or truncated_urn
    distance_id = 'l1-approvalwise'
    embedding_id = 'fr'

    experiment = mapel.prepare_offline_approval_experiment(experiment_id=experiment_id,
                                                           distance_id=distance_id,
                                                           embedding_id=embedding_id)

    # experiment.compute_feature('max_approval_score')  # this feature is precomputed

    experiment.print_map_2d_colored_by_feature(
        cmap='Blues',
        feature_id='max_approval_score',
        textual=['empty', 'full', 'ID 0.5', 'IC 0.5'],
        rounding=0,
    )
