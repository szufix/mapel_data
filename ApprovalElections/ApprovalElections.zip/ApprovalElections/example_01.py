#
# PRINT ORIGINAL MAP
#

import mapel.elections as mapel


if __name__ == "__main__":

    experiment_id = '100x1000/resampling'    # or disjoint or noise or truncated_urn or euclidean
    distance_id = 'l1-approvalwise'
    embedding_id = 'fr'

    experiment = mapel.prepare_offline_approval_experiment(experiment_id=experiment_id,
                                                           distance_id=distance_id,
                                                           embedding_id=embedding_id)

    experiment.print_map_2d(
        legend=False,
        textual=['empty', 'full', 'ID 0.5', 'IC 0.5'],
    )
