#
# PRINT MAP COLORED BY YOUR OWN FEATURE
#

from collections import defaultdict

import mapel.elections as mapel


def my_feature(election) -> dict:
    """ implement your feature here """
    if election.fake:
        return {'value': None}

    score = defaultdict(int)

    for vote in election.votes:
        for i, candidate in enumerate(vote):
            score[candidate] += election.num_candidates - 1 - i

    return {'value': max(score.values())}


if __name__ == "__main__":

    experiment_id = '10x50'
    distance_id = 'swap'
    embedding_id = 'fr'

    experiment = mapel.prepare_offline_ordinal_experiment(experiment_id=experiment_id,
                                                           distance_id=distance_id,
                                                           embedding_id=embedding_id)

    feature_id = 'my_feature'
    experiment.add_feature(feature_id, my_feature)

    experiment.compute_feature(feature_id=feature_id)

    experiment.print_map_2d_colored_by_feature(
        cmap='Oranges',
        feature_id=feature_id,
        textual=['ID', 'UN', 'ST', 'AN'],
        rounding=0,
    )
